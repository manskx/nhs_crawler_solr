package com.manskx.nhscrawler.resources;

public interface ConditionsInsertion {

	public void insertData(String url, String anchor, String title, String header, String contentdata, int hashed_url);

}
