package com.manskx.nhscrawler.resources;
/**
 * This is configuration file
 * @author Ahmed
 *
 */
public class Configurations {
	public static final String SEED_URL	=	"http://www.nhs.uk/conditions/Pages/hub.aspx";
	public static final String URL_PREFIX	=	"http://www.nhs.uk/conditions/";
	public static final int NUMBER_OF_CRAWLERS	=	5;
	public static final int MAX_DEBTH_OF_CRAWLING	=	10;
	public static final int MAX_PAGES_TO_FETCH	=	1000;
	
	public static final String SOLR_BASE_SERVER_URL	=	"http://www.nhs.uk/conditions/Pages/hub.aspx";
	
	public static final int SOLR_HEADER_SCORE	=	10;
	public static final int SOLR_CONTENT_SCORE	=	2;
	public static final int SOLR_ANCHOR_SCORE	=	5;


}
