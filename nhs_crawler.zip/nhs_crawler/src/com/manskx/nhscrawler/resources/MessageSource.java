package com.manskx.nhscrawler.resources;

public class MessageSource {
	public static final String RUNNING_CRALWING = "Crawling is running now !";
	public static final String FINISHED_CRALWING = "Crawling is finished";
	public static final String NOT_STARTED_CRALWING = "Crawling is not started yet";
	public static final String WARNING_CRAWLING_IS_ALREADY_RUNNING = "Crawling is running now, Please try again after finishing crawling";
	public static final String STARTING_CRAWLING = "Crawling starts now !";
	public static final String ERROR_	=	"An error oqquired please try contact admin";
}
