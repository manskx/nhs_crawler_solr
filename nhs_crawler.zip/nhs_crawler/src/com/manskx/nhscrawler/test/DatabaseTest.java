package com.manskx.nhscrawler.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class DatabaseTest {
	@Test
	public void testDatabaseConnection() {

		assertEquals( " "," " );
	}
	
	@Test
	public void testDatabaseInsertion() {

		assertEquals( " "," " );
	}
	
}
